## 运行

`java -jar Wker_CMSSearch.jar http://www.xxx.com`

不要删除cms文件夹下面的CMS.csv那个是本地的指纹库。

工具会联网查找也会本地扫描。
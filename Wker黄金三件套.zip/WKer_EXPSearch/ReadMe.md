## 运行

`java -jar WKer_EXPSearch.jar`

程序生成的扫描信息结果会放在data目录下，有漏洞信息和poc或exp